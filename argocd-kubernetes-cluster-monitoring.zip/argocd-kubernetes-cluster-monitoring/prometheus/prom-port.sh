#!
#pkill -f "kubectl port-forward"

kubectl port-forward -n monitoring svc/prometheus 9090:9090 > prometheus.log 2>&1 &
