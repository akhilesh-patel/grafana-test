#!/bin/bash

kubectl port-forward -n monitoring svc/cadvisor 8080:8080 > cadvisor.log 2>&1 &
kubectl port-forward -n monitoring svc/node-exporter 9100:9100 > node_exporter.log 2>&1 &

echo "Port forwarding started in background"

